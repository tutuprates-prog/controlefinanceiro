// lib/providers/news_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import '../models/news_model.dart';

class NewsState {
  final List<NewsArticle> articles;
  final bool loading;
  final String? error;
  const NewsState({this.articles = const [], this.loading = false, this.error});
  NewsState copyWith({List<NewsArticle>? articles, bool? loading, String? error}) =>
      NewsState(articles: articles ?? this.articles, loading: loading ?? this.loading, error: error);
}

class NewsNotifier extends StateNotifier<NewsState> {
  NewsNotifier() : super(const NewsState()) { fetch(); }

  Future<void> fetch() async {
    state = state.copyWith(loading: true, error: null);
    try {
      // NewsAPI.org — substitua pela sua chave em https://newsapi.org (gratuito)
      const apiKey = 'SUA_CHAVE_AQUI';
      final uri = Uri.parse(
        'https://newsapi.org/v2/everything?q=finan%C3%A7as+economia&language=pt&sortBy=publishedAt&pageSize=8&apiKey=$apiKey',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final list = (data['articles'] as List).map((e) => NewsArticle.fromJson(e as Map<String, dynamic>)).toList();
        state = state.copyWith(articles: list, loading: false);
        return;
      }
    } catch (_) {}
    // Fallback com artigos de exemplo
    state = state.copyWith(loading: false, error: 'offline', articles: _mock());
  }

  List<NewsArticle> _mock() => [
    NewsArticle(title: 'Como controlar suas finanças em 2025', description: 'Dicas práticas para organizar receitas e despesas e alcançar liberdade financeira.', source: 'Finanças Hoje', publishedAt: DateTime.now().subtract(const Duration(hours: 1))),
    NewsArticle(title: 'Regra 50-30-20: o método mais popular para economizar', description: '50% para necessidades, 30% para desejos e 20% para poupança. Saiba como aplicar.', source: 'Investimentos BR', publishedAt: DateTime.now().subtract(const Duration(hours: 4))),
    NewsArticle(title: 'Tesouro Direto: guia completo para iniciantes', description: 'Aprenda a investir com segurança nos títulos públicos do governo federal.', source: 'Renda Fixa', publishedAt: DateTime.now().subtract(const Duration(days: 1))),
    NewsArticle(title: 'Fundo de emergência: por que você precisa ter um', description: 'Especialistas recomendam reservar ao menos 6 meses de despesas como segurança.', source: 'Planejamento Financeiro', publishedAt: DateTime.now().subtract(const Duration(days: 2))),
    NewsArticle(title: 'Inflação e poder de compra: o que você precisa saber', description: 'Entenda como a inflação afeta seu orçamento e como se proteger dos seus efeitos.', source: 'Economia BR', publishedAt: DateTime.now().subtract(const Duration(days: 3))),
  ];
}

final newsProvider = StateNotifierProvider<NewsNotifier, NewsState>((_) => NewsNotifier());
