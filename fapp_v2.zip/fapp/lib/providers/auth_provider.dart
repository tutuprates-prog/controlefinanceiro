// lib/providers/auth_provider.dart
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/storage.dart';
import '../models/user_model.dart';

class AuthState {
  final UserModel? user;
  final bool loading;
  final String? error;
  const AuthState({this.user, this.loading = false, this.error});
  bool get isAuth => user != null;
  AuthState copyWith({UserModel? user, bool? loading, String? error, bool clear = false}) =>
      AuthState(user: clear ? null : user ?? this.user, loading: loading ?? this.loading, error: error);
}

String hashPw(String pw) => sha256.convert(utf8.encode(pw)).toString();

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier() : super(const AuthState());

  Future<bool> login(String email, String password) async {
    state = state.copyWith(loading: true, error: null);
    final user = await Storage.instance.findUserByEmail(email);
    if (user == null) {
      state = state.copyWith(loading: false, error: 'E-mail não encontrado.');
      return false;
    }
    if (user.passwordHash != hashPw(password)) {
      state = state.copyWith(loading: false, error: 'Senha incorreta.');
      return false;
    }
    state = state.copyWith(user: user, loading: false);
    return true;
  }

  Future<bool> register(String name, String email, String password) async {
    state = state.copyWith(loading: true, error: null);
    final emailLower = email.trim().toLowerCase();
    if (await Storage.instance.findUserByEmail(emailLower) != null) {
      state = state.copyWith(loading: false, error: 'E-mail já cadastrado.');
      return false;
    }
    final id = await Storage.instance.insertUser(
      UserModel(id: 0, name: name.trim(), email: emailLower, passwordHash: hashPw(password)),
    );
    state = state.copyWith(
      user: UserModel(id: id, name: name.trim(), email: emailLower, passwordHash: hashPw(password)),
      loading: false,
    );
    return true;
  }

  void logout() => state = const AuthState();
  void clearError() => state = state.copyWith(error: null);
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((_) => AuthNotifier());
