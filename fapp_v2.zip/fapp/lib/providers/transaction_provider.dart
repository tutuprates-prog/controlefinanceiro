// lib/providers/transaction_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/storage.dart';
import '../models/transaction_model.dart';
import 'auth_provider.dart';

class TxState {
  final List<TransactionModel> all;
  final bool loading;
  final String filter; // all | income | expense

  const TxState({this.all = const [], this.loading = false, this.filter = 'all'});

  List<TransactionModel> get filtered {
    if (filter == 'income') return all.where((t) => t.isIncome).toList();
    if (filter == 'expense') return all.where((t) => !t.isIncome).toList();
    return all;
  }

  double get totalIncome => all.where((t) => t.isIncome).fold(0, (s, t) => s + t.amount);
  double get totalExpense => all.where((t) => !t.isIncome).fold(0, (s, t) => s + t.amount);
  double get balance => totalIncome - totalExpense;

  TxState copyWith({List<TransactionModel>? all, bool? loading, String? filter}) =>
      TxState(all: all ?? this.all, loading: loading ?? this.loading, filter: filter ?? this.filter);
}

class TxNotifier extends StateNotifier<TxState> {
  final int userId;
  TxNotifier(this.userId) : super(const TxState()) { load(); }

  Future<void> load() async {
    state = state.copyWith(loading: true);
    final list = await Storage.instance.getTransactions(userId);
    state = state.copyWith(all: list, loading: false);
  }

  Future<void> add(TransactionModel tx) async {
    final saved = await Storage.instance.insertTransaction(tx);
    state = state.copyWith(all: [saved, ...state.all]);
  }

  Future<void> update(TransactionModel tx) async {
    await Storage.instance.updateTransaction(tx);
    state = state.copyWith(all: state.all.map((t) => t.id == tx.id ? tx : t).toList());
  }

  Future<void> delete(int id) async {
    await Storage.instance.deleteTransaction(userId, id);
    state = state.copyWith(all: state.all.where((t) => t.id != id).toList());
  }

  void setFilter(String f) => state = state.copyWith(filter: f);
}

final txProvider = StateNotifierProvider<TxNotifier, TxState>((ref) {
  final uid = ref.watch(authProvider).user?.id ?? 0;
  return TxNotifier(uid);
});
