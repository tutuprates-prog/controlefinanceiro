// lib/models/user_model.dart
class UserModel {
  final int id;
  final String name;
  final String email;
  final String passwordHash;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.passwordHash,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'email': email,
        'passwordHash': passwordHash,
      };

  factory UserModel.fromMap(Map<String, dynamic> m) => UserModel(
        id: m['id'] as int,
        name: m['name'] as String,
        email: m['email'] as String,
        passwordHash: m['passwordHash'] as String,
      );
}
