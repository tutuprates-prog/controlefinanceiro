// lib/models/news_model.dart
class NewsArticle {
  final String title;
  final String? description;
  final String? url;
  final String? source;
  final DateTime? publishedAt;

  const NewsArticle({
    required this.title,
    this.description,
    this.url,
    this.source,
    this.publishedAt,
  });

  factory NewsArticle.fromJson(Map<String, dynamic> j) => NewsArticle(
        title: j['title'] as String? ?? '',
        description: j['description'] as String?,
        url: j['url'] as String?,
        source: (j['source'] as Map?)?.cast<String,dynamic>()['name'] as String?,
        publishedAt: j['publishedAt'] != null ? DateTime.tryParse(j['publishedAt'] as String) : null,
      );
}
