// lib/models/transaction_model.dart
enum TxType { income, expense }

class TransactionModel {
  final int id;
  final int userId;
  final String title;
  final double amount;
  final DateTime date;
  final TxType type;
  final String category;
  final String? description;

  const TransactionModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.amount,
    required this.date,
    required this.type,
    required this.category,
    this.description,
  });

  bool get isIncome => type == TxType.income;

  Map<String, dynamic> toMap() => {
        'id': id,
        'userId': userId,
        'title': title,
        'amount': amount,
        'date': date.toIso8601String(),
        'type': type.name,
        'category': category,
        'description': description,
      };

  factory TransactionModel.fromMap(Map<String, dynamic> m) => TransactionModel(
        id: m['id'] as int,
        userId: m['userId'] as int,
        title: m['title'] as String,
        amount: (m['amount'] as num).toDouble(),
        date: DateTime.parse(m['date'] as String),
        type: TxType.values.byName(m['type'] as String),
        category: m['category'] as String,
        description: m['description'] as String?,
      );

  TransactionModel copyWith({
    int? id,
    String? title,
    double? amount,
    DateTime? date,
    TxType? type,
    String? category,
    String? description,
  }) =>
      TransactionModel(
        id: id ?? this.id,
        userId: userId,
        title: title ?? this.title,
        amount: amount ?? this.amount,
        date: date ?? this.date,
        type: type ?? this.type,
        category: category ?? this.category,
        description: description ?? this.description,
      );

  static const incomeCategories = ['Salário', 'Freelance', 'Investimentos', 'Presente', 'Outros'];
  static const expenseCategories = ['Alimentação', 'Transporte', 'Moradia', 'Saúde', 'Lazer', 'Educação', 'Outros'];
}
