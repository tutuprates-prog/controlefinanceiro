// lib/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/auth_provider.dart';
import '../auth/login_screen.dart';
import 'dashboard_tab.dart';
import '../transactions/transactions_tab.dart';
import '../news/news_tab.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _idx = 0;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider).user;
    final titles = ['Dashboard', 'Transações', 'Notícias'];

    return Scaffold(
      appBar: AppBar(
        title: _idx == 0
            ? Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('Olá, ${user?.name.split(' ').first ?? ''} 👋', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                const Text('Controle Financeiro', style: TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.w400)),
              ])
            : Text(titles[_idx]),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_outlined),
            tooltip: 'Sair',
            onPressed: () {
              ref.read(authProvider.notifier).logout();
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
            },
          ),
        ],
      ),
      body: IndexedStack(index: _idx, children: const [DashboardTab(), TransactionsTab(), NewsTab()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        onDestinationSelected: (i) => setState(() => _idx = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transações'),
          NavigationDestination(icon: Icon(Icons.newspaper_outlined), selectedIcon: Icon(Icons.newspaper), label: 'Notícias'),
        ],
      ),
    );
  }
}
