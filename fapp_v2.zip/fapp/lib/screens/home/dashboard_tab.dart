// lib/screens/home/dashboard_tab.dart
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/transaction_provider.dart';
import '../../widgets/skeleton.dart';
import '../../widgets/transaction_sheet.dart';

class DashboardTab extends ConsumerWidget {
  const DashboardTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(txProvider);
    final fmt = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final cs = Theme.of(context).colorScheme;

    if (state.loading) return const DashSkeleton();

    final isPos = state.balance >= 0;

    return RefreshIndicator(
      onRefresh: () => ref.read(txProvider.notifier).load(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
        children: [
          // Saldo card
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isPos ? [const Color(0xFF2563EB), const Color(0xFF1D4ED8)] : [Colors.red.shade600, Colors.red.shade800],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [BoxShadow(color: (isPos ? cs.primary : Colors.red).withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Saldo atual', style: TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 6),
              Text(fmt.format(state.balance), style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -1)),
              const SizedBox(height: 14),
              Row(children: [
                _chip('↓ Entradas', fmt.format(state.totalIncome), Colors.greenAccent.shade400),
                const SizedBox(width: 20),
                _chip('↑ Saídas', fmt.format(state.totalExpense), Colors.red.shade300),
              ]),
            ]),
          ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.05),

          const SizedBox(height: 16),

          // Gráfico pizza
          if (state.all.isNotEmpty && (state.totalIncome + state.totalExpense) > 0)
            _ChartCard(state: state).animate().fadeIn(delay: 150.ms),

          const SizedBox(height: 16),

          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Últimas transações', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            TextButton.icon(
              onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => const TransactionSheet()),
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Adicionar'),
            ),
          ]),
          const SizedBox(height: 8),

          if (state.all.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 32),
                child: Column(children: [
                  Icon(Icons.receipt_long_outlined, size: 56, color: Colors.grey.shade300),
                  const SizedBox(height: 10),
                  Text('Nenhuma transação ainda', style: TextStyle(color: Colors.grey.shade400)),
                ]),
              ),
            )
          else
            ...state.all.take(5).map((tx) => _TxTile(tx: tx)).toList(),
        ],
      ),
    );
  }

  Widget _chip(String label, String value, Color color) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
    const SizedBox(height: 2),
    Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
  ]);
}

class _ChartCard extends StatelessWidget {
  final TxState state;
  const _ChartCard({required this.state});
  @override
  Widget build(BuildContext context) {
    final total = state.totalIncome + state.totalExpense;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Distribuição', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        SizedBox(height: 140, child: Row(children: [
          Expanded(child: PieChart(PieChartData(
            sections: [
              PieChartSectionData(value: state.totalIncome, color: Colors.green, title: '${(state.totalIncome / total * 100).toStringAsFixed(0)}%', radius: 52, titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
              PieChartSectionData(value: state.totalExpense, color: Colors.redAccent, title: '${(state.totalExpense / total * 100).toStringAsFixed(0)}%', radius: 52, titleStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
            ],
            sectionsSpace: 2, centerSpaceRadius: 28,
          ))),
          const SizedBox(width: 16),
          Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
            _legend(Colors.green, 'Receitas'),
            const SizedBox(height: 10),
            _legend(Colors.redAccent, 'Despesas'),
          ]),
        ])),
      ]),
    );
  }
  Widget _legend(Color c, String l) => Row(children: [Container(width: 12, height: 12, decoration: BoxDecoration(color: c, shape: BoxShape.circle)), const SizedBox(width: 6), Text(l, style: const TextStyle(fontSize: 13))]);
}

class _TxTile extends ConsumerWidget {
  final tx;
  const _TxTile({required this.tx});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fmt = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final isIncome = tx.isIncome;
    return Dismissible(
      key: Key('d_${tx.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 16), margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async => await showDialog<bool>(context: context, builder: (_) => AlertDialog(
        title: const Text('Excluir?'), content: Text('Remover "${tx.title}"?'),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir', style: TextStyle(color: Colors.red)))],
      )),
      onDismissed: (_) => ref.read(txProvider.notifier).delete(tx.id),
      child: InkWell(
        onTap: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => TransactionSheet(existing: tx)),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))]),
          child: Row(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: (isIncome ? Colors.green : Colors.red).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(isIncome ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded, color: isIncome ? Colors.green : Colors.red, size: 20)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
              Text('${tx.category}', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
            ])),
            Text('${isIncome ? '+' : '-'} ${fmt.format(tx.amount)}', style: TextStyle(color: isIncome ? Colors.green : Colors.red, fontWeight: FontWeight.w700, fontSize: 14)),
          ]),
        ),
      ),
    ).animate().fadeIn().slideX(begin: 0.02);
  }
}
