// lib/screens/news/news_tab.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/news_provider.dart';
import '../../widgets/skeleton.dart';

class NewsTab extends ConsumerWidget {
  const NewsTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(newsProvider);

    if (state.loading) return const NewsSkeleton();

    return RefreshIndicator(
      onRefresh: () => ref.read(newsProvider.notifier).fetch(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(8)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.trending_up, size: 14, color: Colors.blue.shade700),
              const SizedBox(width: 6),
              Text('Dicas & Notícias Financeiras', style: TextStyle(fontSize: 12, color: Colors.blue.shade700, fontWeight: FontWeight.w600)),
            ]),
          ).animate().fadeIn(),
          const SizedBox(height: 12),

          if (state.error != null)
            Container(
              padding: const EdgeInsets.all(10), margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(color: Colors.amber.shade50, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.amber.shade200)),
              child: Row(children: [
                Icon(Icons.info_outline, color: Colors.amber.shade700, size: 16),
                const SizedBox(width: 8),
                Expanded(child: Text('Exibindo artigos de exemplo. Configure uma chave NewsAPI para dados reais.', style: TextStyle(fontSize: 12, color: Colors.amber.shade800))),
              ]),
            ).animate().fadeIn(),

          ...state.articles.asMap().entries.map((e) => _NewsCard(article: e.value)
              .animate().fadeIn(delay: Duration(milliseconds: e.key * 60)).slideY(begin: 0.04)),
        ],
      ),
    );
  }
}

class _NewsCard extends StatelessWidget {
  final article;
  const _NewsCard({required this.article});

  String _ago(DateTime? dt) {
    if (dt == null) return '';
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}min atrás';
    if (diff.inHours < 24) return '${diff.inHours}h atrás';
    return DateFormat('dd/MM').format(dt);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(article.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14), maxLines: 3, overflow: TextOverflow.ellipsis),
          if (article.description != null) ...[
            const SizedBox(height: 6),
            Text(article.description!, style: TextStyle(fontSize: 12, color: Colors.grey.shade600), maxLines: 2, overflow: TextOverflow.ellipsis),
          ],
          const SizedBox(height: 10),
          Row(children: [
            if (article.source != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(5)),
                child: Text(article.source!, style: TextStyle(fontSize: 10, color: Colors.blue.shade700, fontWeight: FontWeight.w600)),
              ),
            const SizedBox(width: 8),
            Text(_ago(article.publishedAt), style: TextStyle(fontSize: 11, color: Colors.grey.shade400)),
          ]),
        ]),
      ),
    );
  }
}
