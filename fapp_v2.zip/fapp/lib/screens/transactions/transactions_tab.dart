// lib/screens/transactions/transactions_tab.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/transaction_provider.dart';
import '../../widgets/transaction_sheet.dart';

class TransactionsTab extends ConsumerWidget {
  const TransactionsTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(txProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => const TransactionSheet()),
        icon: const Icon(Icons.add),
        label: const Text('Adicionar'),
      ),
      body: Column(children: [
        // Filtros
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(children: [
            _Chip(label: 'Todas', selected: state.filter == 'all', onTap: () => ref.read(txProvider.notifier).setFilter('all')),
            const SizedBox(width: 8),
            _Chip(label: 'Receitas', selected: state.filter == 'income', color: Colors.green, onTap: () => ref.read(txProvider.notifier).setFilter('income')),
            const SizedBox(width: 8),
            _Chip(label: 'Despesas', selected: state.filter == 'expense', color: Colors.red, onTap: () => ref.read(txProvider.notifier).setFilter('expense')),
          ]),
        ),
        const SizedBox(height: 10),

        Expanded(
          child: state.loading
              ? const Center(child: CircularProgressIndicator())
              : state.filtered.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.receipt_long_outlined, size: 60, color: Colors.grey.shade300),
                      const SizedBox(height: 12),
                      Text('Nenhuma transação encontrada', style: TextStyle(color: Colors.grey.shade400)),
                    ]))
                  : RefreshIndicator(
                      onRefresh: () => ref.read(txProvider.notifier).load(),
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                        itemCount: state.filtered.length,
                        itemBuilder: (ctx, i) => _TxCard(tx: state.filtered[i])
                            .animate().fadeIn(delay: Duration(milliseconds: i * 40)).slideY(begin: 0.04),
                      ),
                    ),
        ),
      ]),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool selected;
  final Color? color;
  final VoidCallback onTap;
  const _Chip({required this.label, required this.selected, this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).colorScheme.primary;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(color: selected ? c : Colors.grey.shade200, borderRadius: BorderRadius.circular(20)),
        child: Text(label, style: TextStyle(color: selected ? Colors.white : Colors.grey.shade700, fontWeight: FontWeight.w600, fontSize: 13)),
      ),
    );
  }
}

class _TxCard extends ConsumerWidget {
  final tx;
  const _TxCard({required this.tx});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fmt = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');
    final isIncome = tx.isIncome;

    return Dismissible(
      key: Key('txc_${tx.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(14)),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async => await showDialog<bool>(context: context, builder: (_) => AlertDialog(
        title: const Text('Excluir?'), content: Text('Remover "${tx.title}"?'),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Excluir', style: TextStyle(color: Colors.red)))],
      )),
      onDismissed: (_) => ref.read(txProvider.notifier).delete(tx.id),
      child: Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => TransactionSheet(existing: tx)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Container(width: 44, height: 44,
                decoration: BoxDecoration(color: (isIncome ? Colors.green : Colors.red).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                child: Icon(isIncome ? Icons.south_east_rounded : Icons.north_west_rounded, color: isIncome ? Colors.green : Colors.red, size: 22)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tx.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Row(children: [
                  Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(6)),
                    child: Text(tx.category, style: TextStyle(fontSize: 11, color: Colors.grey.shade600, fontWeight: FontWeight.w500))),
                  const SizedBox(width: 6),
                  Text(DateFormat('dd/MM/yyyy').format(tx.date), style: TextStyle(fontSize: 11, color: Colors.grey.shade400)),
                ]),
                if (tx.description != null) ...[
                  const SizedBox(height: 2),
                  Text(tx.description!, style: TextStyle(fontSize: 12, color: Colors.grey.shade500), maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              ])),
              const SizedBox(width: 8),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('${isIncome ? '+' : '-'} ${fmt.format(tx.amount)}', style: TextStyle(color: isIncome ? Colors.green : Colors.red, fontWeight: FontWeight.w800, fontSize: 15)),
                const SizedBox(height: 4),
                Icon(Icons.edit_outlined, size: 14, color: Colors.grey.shade400),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
