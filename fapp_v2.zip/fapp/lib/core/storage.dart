// lib/core/storage.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/transaction_model.dart';

class Storage {
  static final Storage instance = Storage._();
  Storage._();

  // ── USERS ──────────────────────────────────────────────
  Future<List<UserModel>> getUsers() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('users') ?? '[]';
    final list = jsonDecode(raw) as List;
    return list.map((e) => UserModel.fromMap(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> saveUsers(List<UserModel> users) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('users', jsonEncode(users.map((u) => u.toMap()).toList()));
  }

  Future<UserModel?> findUserByEmail(String email) async {
    final users = await getUsers();
    try {
      return users.firstWhere((u) => u.email == email.toLowerCase().trim());
    } catch (_) {
      return null;
    }
  }

  Future<int> insertUser(UserModel user) async {
    final users = await getUsers();
    final id = DateTime.now().millisecondsSinceEpoch;
    users.add(UserModel(id: id, name: user.name, email: user.email, passwordHash: user.passwordHash));
    await saveUsers(users);
    return id;
  }

  // ── TRANSACTIONS ───────────────────────────────────────
  Future<List<TransactionModel>> getTransactions(int userId) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('tx_$userId') ?? '[]';
    final list = jsonDecode(raw) as List;
    return list
        .map((e) => TransactionModel.fromMap(Map<String, dynamic>.from(e as Map)))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  Future<void> _saveTransactions(int userId, List<TransactionModel> txs) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tx_$userId', jsonEncode(txs.map((t) => t.toMap()).toList()));
  }

  Future<TransactionModel> insertTransaction(TransactionModel tx) async {
    final txs = await getTransactions(tx.userId);
    final id = DateTime.now().millisecondsSinceEpoch;
    final saved = TransactionModel(
      id: id, userId: tx.userId, title: tx.title,
      amount: tx.amount, date: tx.date, type: tx.type,
      category: tx.category, description: tx.description,
    );
    txs.insert(0, saved);
    await _saveTransactions(tx.userId, txs);
    return saved;
  }

  Future<void> updateTransaction(TransactionModel tx) async {
    final txs = await getTransactions(tx.userId);
    final idx = txs.indexWhere((t) => t.id == tx.id);
    if (idx != -1) txs[idx] = tx;
    await _saveTransactions(tx.userId, txs);
  }

  Future<void> deleteTransaction(int userId, int id) async {
    final txs = await getTransactions(userId);
    txs.removeWhere((t) => t.id == id);
    await _saveTransactions(userId, txs);
  }
}
