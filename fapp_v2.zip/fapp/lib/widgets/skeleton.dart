// lib/widgets/skeleton.dart
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

Widget skeletonBox({double w = double.infinity, double h = 16, double r = 8}) =>
    Shimmer.fromColors(
      baseColor: Colors.grey.shade200,
      highlightColor: Colors.grey.shade100,
      child: Container(width: w, height: h, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(r))),
    );

class DashSkeleton extends StatelessWidget {
  const DashSkeleton({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    skeletonBox(h: 160, r: 20), const SizedBox(height: 16),
    Row(children: [Expanded(child: skeletonBox(h: 90, r: 16)), const SizedBox(width: 12), Expanded(child: skeletonBox(h: 90, r: 16))]),
    const SizedBox(height: 16),
    ...List.generate(4, (_) => Padding(padding: const EdgeInsets.only(bottom: 10), child: skeletonBox(h: 64, r: 12))),
  ]);
}

class NewsSkeleton extends StatelessWidget {
  const NewsSkeleton({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: List.generate(5, (_) =>
    Padding(padding: const EdgeInsets.only(bottom: 12), child: Shimmer.fromColors(
      baseColor: Colors.grey.shade200, highlightColor: Colors.grey.shade100,
      child: Container(height: 100, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16))),
    )),
  ));
}
